from test.test_email import load_tests
import unittest

unittest.main()
