#! /usr/bin/python3.8
print '#coding=0'
