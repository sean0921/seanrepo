#ifndef __wasilibc___typedef_ino_t_h
#define __wasilibc___typedef_ino_t_h

/* Define these as 64-bit integers to support billions of inodes. */
typedef unsigned long long ino_t;

#endif
