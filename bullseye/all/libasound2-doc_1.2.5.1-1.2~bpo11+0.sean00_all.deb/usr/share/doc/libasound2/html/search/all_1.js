var searchData=
[
  ['abstract_33',['abstract',['../structsnd__mixer__selem__regopt.html#a62d43bde34692931ead4ad14b5ad9821',1,'snd_mixer_selem_regopt']]],
  ['access_34',['access',['../structsnd__pcm__ioplug.html#ac49bda6dd5d2e530d50478be89365ddc',1,'snd_pcm_ioplug::access()'],['../group__topology.html#ga0a3e7fa10db19ea81524fe6a55f92e94',1,'snd_tplg_ctl_template::access()']]],
  ['access_20mask_20functions_35',['Access Mask Functions',['../group___p_c_m___access.html',1,'']]],
  ['addr_36',['addr',['../structsnd__pcm__channel__area__t.html#a83acdf3245dcb74dffe74cce53d65876',1,'snd_pcm_channel_area_t::addr()'],['../structsnd__seq__event__t.html#a3a2df2fd3def9f0443bd4759b3cf4077',1,'snd_seq_event_t::addr()']]],
  ['alsa_20topology_20interface_37',['ALSA Topology Interface',['../group__topology.html',1,'']]],
  ['alsa_20use_20case_20interface_38',['ALSA Use Case Interface',['../group__ucm.html',1,'']]],
  ['alsa_5fconfig_5fpath_5fvar_39',['ALSA_CONFIG_PATH_VAR',['../conf_8c.html#a8b857484628b5b4cbd2ac60503d4f80e',1,'conf.c']]],
  ['appl_5fptr_40',['appl_ptr',['../structsnd__pcm__ioplug.html#a66cf297ebbce9453b4bbd961f081c730',1,'snd_pcm_ioplug']]],
  ['asoundef_2eh_41',['asoundef.h',['../asoundef_8h.html',1,'']]],
  ['asoundlib_2eh_42',['asoundlib.h',['../asoundlib_8h.html',1,'']]],
  ['async_2ec_43',['async.c',['../async_8c.html',1,'']]],
  ['audio_5fhw_5fformat_44',['audio_hw_format',['../structaudio__hw__format.html',1,'']]]
];
