var searchData=
[
  ['pcm_20_28digital_20audio_29_20interface_5226',['PCM (digital audio) interface',['../pcm.html',1,'']]],
  ['pcm_20_28digital_20audio_29_20plugins_5227',['PCM (digital audio) plugins',['../pcm_plugins.html',1,'']]],
  ['pcm_20external_20plugin_20sdk_5228',['PCM External Plugin SDK',['../pcm_external_plugins.html',1,'']]],
  ['primitive_20control_20plugins_5229',['Primitive control plugins',['../control_plugins.html',1,'']]]
];
