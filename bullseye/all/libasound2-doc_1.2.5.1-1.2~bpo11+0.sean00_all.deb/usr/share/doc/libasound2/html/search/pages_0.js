var searchData=
[
  ['alsa_20topology_20interface_5216',['ALSA Topology Interface',['../group__topology.html',1,'']]],
  ['alsa_20use_20case_20interface_5217',['ALSA Use Case Interface',['../group__ucm.html',1,'']]]
];
