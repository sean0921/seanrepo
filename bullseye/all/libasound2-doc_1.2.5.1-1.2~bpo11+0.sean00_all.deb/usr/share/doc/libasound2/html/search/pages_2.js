var searchData=
[
  ['configuration_20files_5219',['Configuration files',['../conf.html',1,'']]],
  ['control_20interface_5220',['Control interface',['../control.html',1,'']]]
];
