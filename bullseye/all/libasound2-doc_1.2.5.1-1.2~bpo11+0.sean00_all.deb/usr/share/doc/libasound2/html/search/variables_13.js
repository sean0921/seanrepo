var searchData=
[
  ['val_4660',['val',['../structsnd__timer__tread__t.html#abcc89d10ed874ec570d1c260ab7d8a71',1,'snd_timer_tread_t']]],
  ['value_4661',['value',['../structsnd__seq__ev__ctrl__t.html#ab0bd2b7b3297df12c1c0bf8ab71ae1df',1,'snd_seq_ev_ctrl_t::value()'],['../structsnd__seq__queue__skew__t.html#a875b622719a77813b9c826cb87664c09',1,'snd_seq_queue_skew_t::value()'],['../structsnd__seq__ev__queue__control__t.html#a6fe9b082ffe83dfabb0e335664d73ab7',1,'snd_seq_ev_queue_control_t::value()']]],
  ['values_4662',['values',['../group__topology.html#ga16bdcaa3cec9d1a73bcda6e366bbc345',1,'snd_tplg_enum_template']]],
  ['velocity_4663',['velocity',['../structsnd__seq__ev__note__t.html#a92516544f8de5cd35d4eec124f53aa29',1,'snd_seq_ev_note_t']]],
  ['vendor_5ftype_4664',['vendor_type',['../group__topology.html#ga8ab68f45554811560909ff630f59d6c1',1,'snd_tplg_obj_template_t']]],
  ['ver_4665',['ver',['../structsnd__mixer__selem__regopt.html#a27a098833de8ddd7434870f301e6355b',1,'snd_mixer_selem_regopt']]],
  ['version_4666',['version',['../structsnd__pcm__extplug.html#a91421a1d534f85fc70b2303f955a0f6b',1,'snd_pcm_extplug::version()'],['../structsnd__pcm__ioplug.html#a82212f3b4b3faf86e4cd94f73f3709f7',1,'snd_pcm_ioplug::version()'],['../structsnd__ctl__ext.html#af3599d3baa6b5ceadecbfbd74b8b773f',1,'snd_ctl_ext::version()'],['../group__topology.html#ga21e20bff5cedad485802af1362d6810b',1,'snd_tplg_obj_template_t::version()']]]
];
