// Note: This was renamed to `pl_log`.
#include <libplacebo/log.h>
