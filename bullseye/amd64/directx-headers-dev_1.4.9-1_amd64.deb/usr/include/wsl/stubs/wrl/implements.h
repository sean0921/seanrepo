// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.

// Stub to satisfy DML TF runtime includes
#pragma once
#include "wrladapter.h"